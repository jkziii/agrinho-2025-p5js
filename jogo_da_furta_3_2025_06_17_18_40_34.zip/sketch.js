let player;
let fruits = [];
let trashItems = []; // Array para itens de lixo
let score = 0;
let lives = 3;
let gameOver = false;

let lastItemTime = 0; // Um único contador para frutas e lixos
const itemInterval = 600; // Milissegundos entre um item caindo e outro

// Chance de cair lixo (0.0 a 1.0)
const trashChance = 0.3; // 30% de chance de cair lixo

function setup() {
  createCanvas(400, 300); // Canvas reduzido para 400x300
  player = new Player();
  rectMode(CENTER); // Facilita o posicionamento de retângulos
  noStroke(); // Remove o contorno das formas
}

function draw() {
  background(173, 216, 230); // Azul claro para o céu

  if (!gameOver) {
    player.update();
    player.show();

    // Gerar frutas ou lixos
    if (millis() - lastItemTime > itemInterval) {
      if (random(1) < trashChance) { // Checa a chance de cair lixo
        trashItems.push(new Trash());
      } else {
        fruits.push(new Fruit());
      }
      lastItemTime = millis();
    }

    // Atualizar e exibir frutas
    for (let i = fruits.length - 1; i >= 0; i--) {
      fruits[i].update();
      fruits[i].show();

      // Colisão com o jogador (fruta)
      if (player.collects(fruits[i])) {
        score += 10; // Ganha 10 pontos por fruta
        fruits.splice(i, 1); // Remove a fruta após ser coletada
      }
      // Fruta caiu no chão
      else if (fruits[i].offscreen()) {
        lives--; // Perde uma vida se a fruta cair
        fruits.splice(i, 1); // Remove a fruta
        if (lives <= 0) {
          gameOver = true;
        }
      }
    }

    // Atualizar e exibir itens de lixo
    for (let i = trashItems.length - 1; i >= 0; i--) {
      trashItems[i].update();
      trashItems[i].show();

      // Colisão com o jogador (lixo)
      if (player.collects(trashItems[i])) {
        score -= 15; // Perde 15 pontos por lixo!
        // Garante que a pontuação não seja negativa (opcional)
        score = max(0, score);
        trashItems.splice(i, 1);
      }
      // Lixo caiu no chão (apenas o remove, não perde vida)
      else if (trashItems[i].offscreen()) {
        trashItems.splice(i, 1);
      }
    }

    // Exibir pontuação e vidas
    fill(0);
    textSize(24);
    textAlign(LEFT, TOP);
    text('Pontuação: ' + score, 10, 10);
    text('Vidas: ' + lives, 10, 40);

  } else {
    // Tela de Game Over
    fill(255, 0, 0);
    textSize(48);
    textAlign(CENTER, CENTER);
    text('GAME OVER', width / 2, height / 2 - 40);
    textSize(24);
    text('Pontuação Final: ' + score, width / 2, height / 2 + 10);
    textSize(18);
    text('Pressione R para Reiniciar', width / 2, height / 2 + 60);
  }
}

// --- Funções de Controle de Teclado (W S D A) ---
function keyPressed() {
  if (key === 'a' || key === 'A') { // Mover para a esquerda
    player.setDir(-1);
  } else if (key === 'd' || key === 'D') { // Mover para a direita
    player.setDir(1);
  } else if (key === 'r' || key === 'R') { // Reiniciar o jogo
    if (gameOver) {
      resetGame();
    }
  }
}

function keyReleased() {
  // Para de mover horizontalmente quando 'A' ou 'D' são soltas
  if (key === 'a' || key === 'A' || key === 'd' || key === 'D') {
    player.setDir(0);
  }
}

// --- Classes ---

// Classe do Personagem (a Cesta)
class Player {
  constructor() {
    this.width = 80;
    this.height = 20;
    this.x = width / 2;
    this.y = height - 30; // Quase no fundo da tela
    this.speed = 7;
    this.dir = 0; // -1 para esquerda, 0 para parado, 1 para direita
  }

  update() {
    this.x += this.dir * this.speed;
    this.x = constrain(this.x, this.width / 2, width - this.width / 2); // Não sai das bordas
  }

  show() {
    fill(139, 69, 19); // Marrom para a cesta
    rect(this.x, this.y, this.width, this.height);
  }

  setDir(dir) {
    this.dir = dir;
  }

  // Verifica se coletou um item (pode ser fruta ou lixo)
  collects(item) {
    // Colisão AABB (Axis-Aligned Bounding Box) para retângulos
    // Para um retângulo (player) e um círculo (fruit/trash) simplificado
    // Verifica se os retângulos de colisão se sobrepõem
    return (item.x + item.size / 2 > this.x - this.width / 2 &&
            item.x - item.size / 2 < this.x + this.width / 2 &&
            item.y + item.size / 2 > this.y - this.height / 2 &&
            item.y - item.size / 2 < this.y + this.height / 2);
  }
}

// Classe da Fruta
class Fruit {
  constructor() {
    this.x = random(width);
    this.y = -20; // Começa acima da tela
    this.size = random(20, 35); // Tamanho da fruta
    this.speed = random(2, 5); // Velocidade de queda
    this.type = floor(random(3)); // 0: Maçã, 1: Banana, 2: Cereja
    this.color = this.getFruitColor(this.type);
  }

  getFruitColor(type) {
    switch (type) {
      case 0: return color(255, 0, 0); // Vermelho (Maçã)
      case 1: return color(255, 255, 0); // Amarelo (Banana)
      case 2: return color(200, 0, 50); // Cereja
      default: return color(100);
    }
  }

  update() {
    this.y += this.speed;
  }

  show() {
    fill(this.color);
    ellipse(this.x, this.y, this.size, this.size); // Desenha a fruta como um círculo simples

    // Detalhes extras para as frutas (opcional)
    if (this.type === 0) { // Maçã: pequena haste
      fill(100, 50, 0);
      rect(this.x, this.y - this.size / 2 - 5, 2, 8);
    } else if (this.type === 2) { // Cereja: dois círculos pequenos
      fill(this.color);
      ellipse(this.x + this.size/4, this.y + this.size/4, this.size/2, this.size/2);
      stroke(100, 50, 0);
      strokeWeight(2);
      line(this.x, this.y - this.size/2, this.x + this.size/4, this.y + this.size/4 - this.size/2);
      noStroke(); // Reset stroke
    }
  }

  offscreen() {
    return this.y > height + this.size / 2;
  }
}

// --- CLASSE: LIXO ---
class Trash {
  constructor() {
    this.x = random(width);
    this.y = -20;
    this.size = random(25, 40); // Lixos podem ser um pouco maiores
    this.speed = random(4, 7); // Podem cair um pouco mais rápido
    this.color = color(100, 100, 100); // Cinza (genérico)
    this.type = floor(random(2)); // 0: lata, 1: garrafa (representação simples)
  }

  update() {
    this.y += this.speed;
  }

  show() {
    fill(this.color);
    if (this.type === 0) { // Lata
      rect(this.x, this.y, this.size * 0.7, this.size);
      fill(50); // Tampa da lata
      rect(this.x, this.y - this.size / 2 + 2, this.size * 0.8, 5);
    } else { // Garrafa
      ellipse(this.x, this.y, this.size * 0.6, this.size);
      fill(this.color);
      rect(this.x, this.y - this.size * 0.4, this.size * 0.3, this.size * 0.3); // Gargalo
    }
  }

  offscreen() {
    return this.y > height + this.size / 2;
  }
}

// Função para reiniciar o jogo
function resetGame() {
  score = 0;
  lives = 3;
  fruits = [];
  trashItems = []; // Reinicia também a lista de lixos
  gameOver = false;
  player = new Player();
  lastItemTime = millis();
}